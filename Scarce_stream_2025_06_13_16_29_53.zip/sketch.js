let balde;
let gotas = [];
let obstaculos = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(400, 400);
  balde = new Balde();  // Cria o balde
}

function draw() {
  background(200);
  
  if (gameOver) {
    textSize(32);
    fill(0);
    text("Game Over!", 100, height / 2);
    noLoop();  // Para o jogo quando acabar
  } else {
    balde.move();  // Movimento do balde
    balde.display();  // Desenha o balde

    // Adiciona e move as gotas de água
    if (frameCount % 60 === 0) {  // Gera uma gota a cada segundo
      gotas.push(new Gota());
      obstaculos.push(new Obstaculo());
    }
    
    for (let i = gotas.length - 1; i >= 0; i--) {
      gotas[i].fall();  // Faz a gota cair
      gotas[i].display();  // Exibe a gota

      if (gotas[i].hits(balde)) {
        score++;  // Ganha um ponto se pegar a gota
        gotas.splice(i, 1);  // Remove a gota
      } else if (gotas[i].offScreen()) {
        gotas.splice(i, 1);  // Remove a gota se sair da tela
      }
    }

    // Lógica dos obstáculos
    for (let i = obstaculos.length - 1; i >= 0; i--) {
      obstaculos[i].fall();
      obstaculos[i].display();

      if (obstaculos[i].hits(balde)) {
        gameOver = true;  // Acabou o jogo se o balde colidir com um obstáculo
      } else if (obstaculos[i].offScreen()) {
        obstaculos.splice(i, 1);  // Remove o obstáculo se sair da tela
      }
    }

    // Exibe o placar
    fill(0);
    textSize(18);
    text("Pontuação: " + score, 20, 30);
  }
}

// Classe do Balde
class Balde {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.width = 50;
    this.height = 30;
    this.speed = 5;
  }

  move() {
    // Movimenta para a esquerda se a seta para a esquerda for pressionada
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    // Movimenta para a direita se a seta para a direita for pressionada
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }

    // Impede que o balde ultrapasse os limites da tela
    this.x = constrain(this.x, 0, width - this.width);
  }

  display() {
    fill(255, 0, 0);  // Cor do balde (vermelho)
    rect(this.x, this.y, this.width, this.height);
  }
}

// Classe da Gota de Água
class Gota {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.diameter = 20;
    this.speed = 3;
  }

  fall() {
    this.y += this.speed;
  }

  display() {
    fill(0, 0, 255);  // Cor da água (azul)
    noStroke();
    ellipse(this.x, this.y, this.diameter);
  }

  hits(balde) {
    // Calcular a distância entre o centro da gota e o balde
    let distX = this.x - balde.x - balde.width / 2;
    let distY = this.y - balde.y - balde.height / 2;
    let distance = Math.sqrt(distX * distX + distY * distY);
    
    // Se a distância for menor que a soma dos raios (diâmetro da gota + metade da largura do balde), houve colisão
    return distance < this.diameter / 2 + balde.width / 2;
  }

  offScreen() {
    return this.y > height;
  }
}

// Classe do Obstáculo
class Obstaculo {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 30;
    this.speed = 3;
  }

  fall() {
    this.y += this.speed;
  }

  display() {
    fill(0);  // Cor do obstáculo (preto)
    noStroke();
    rect(this.x, this.y, this.size, this.size);
  }

  hits(balde) {
    return this.x < balde.x + balde.width &&
           this.x + this.size > balde.x &&
           this.y < balde.y + balde.height &&
           this.y + this.size > balde.y;
  }

  offScreen() {
    return this.y > height;
  }
}